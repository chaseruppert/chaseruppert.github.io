/**
    \file imperialMessengers.c

    \brief Visual Concepts "Imperial Messenger" programming test.

    This program attempts to solve for how long a message takes to distribute
    throughout an entire "network" of cities (the empire) from a source, the
    capitol.

    #defines that change this program's behavior:
    - DIAGNOSTIC_LOGGING: outputs more diagnostic/debugging info to stdout.
        Only intended for debug builds.
    - UNIT_TEST: executes unit-tests at runtime prior to main program
        execution. Unit tests are enforced via asserts.

    The algorithm chosen to solve this problem:
    1) Initialize a "minimum path length" array that stores the minimum
        travel time to distribute a message from the capitol to a given
        city.
    2) Send the message to each of the cities adjacent to the capitol
    3) When a message arrives to a city:
        - check if the message has already visited this city; if so, ignore
            it and don't propagate it any further.
        - calculate the message's total accumulated travel time thus far.
        - compare the total travel time with this city's "minimum path 
            length" array entry. If the current total travel is less than the
            entry, replace it (since we found a path that takes less time for
            a message to get to that city).
        - send the message to each of the city's adjacent cities.
    4) Once message traversal has completed for the entire empire, return the
        the maximum value in the "minimum path length" array; this is the 
        time it takes for a message to be distributed throughout the empire.

    Alternate algorithms/solutions considered:
    - The chosen algorithm is recursive, although a stack-based approach was
        also considered. This would have impacted the data representation and
        management of messages. For example, when visiting a city, with a 
        stack-based approach, we would "push" the adjacent cities to the 
        stack and also store their travel times along with the city 
        identifiers in the stack. Then we would continue to iterate with a 
        while-loop until the stack was empty (popping off messages/cities as
        we visit them).

        This would've meant that, for each adjacent city, we would have 
        needed to create a copy of the message to visit other cities. The
        recursive approach seemed more elegant since the "message" itself was
        implied via recursive function call (along with whatever other 
        necessary parameters) and didn't really need a specific data type to
        represent it.

    Terminology:
    - cities that are adjacent to each other are sometimes referred to as
        "connected"
    - the travel time between two cities may be referred to as a "length" or
        "weight".

    Sample Input
    5               // Number of cities (includes the capitol)
    50              // (2,1)
    30 	5           // (3,1) (3,2)
    100 20	50      // (4,1) (4,2) (4,3)
    10 	x 	x 	10  // (5,1) ...   ...   (5,4)

    Output for the Sample Input
    35

    Update 4/9:
    Fixed two issues:
    - messages continued to send throughout the empire  even if they arrived
        at a city where the message had already been delivered more quickly.
    - resolved minor type inconsistency issue

    Before fixing the issue, the number of iterations required to traverse
    a completely interconnected empire was fairly astronomical:
    Num cities = 2, send message called 1 times.
    Num cities = 3, send message called 6 times.
    Num cities = 4, send message called 33 times.
    Num cities = 5, send message called 196 times.
    Num cities = 6, send message called 1305 times.
    Num cities = 7, send message called 9786 times.
    Num cities = 8, send message called 82201 times.
    Num cities = 9, send message called 767208 times.
    Num cities = 10, send message called 7891281 times.
    Num cities = 11, send message called 88776910 times.

    After resolving the issue:
    Num cities = 2, send message called 1 times.
    Num cities = 3, send message called 5 times.
    Num cities = 4, send message called 15 times.
    Num cities = 5, send message called 34 times.
    Num cities = 6, send message called 65 times.
    Num cities = 7, send message called 111 times.
    Num cities = 8, send message called 175 times.
    Num cities = 9, send message called 260 times.
    Num cities = 10, send message called 369 times.
    Num cities = 11, send message called 505 times.

    Time spent:
    3/31    0.5     2300-2330
    4/1     1.5     2115-2245
    4/2     4.25    2100-2215, 2315-0215
    4/4     6.75    2045-2100, 2130-0400
    4/5     4.75    2115-0200
    4/8     1.25    2200-2245, 2345-0015
    4/9         2200-

    \author Chase Ruppert (chase.ruppert@live.com)
*/

#include <stdio.h>
#include <limits.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

/** 
    Maximum number of cities allowed. 
    
    \warn :WARN: Increasing this number will likely impact this implementation!
*/
#define MAX_NUM_CITIES  100

/** Capitol city has a special case identifier as zero */
static const unsigned int CAPITOL_CITY = 0;

/** Simple char-based C "bool" type (mostly to improve code readability). */
typedef char bool;
static const bool TRUE  = 1;
static const bool FALSE = 0;

/** We don't support zero cities - this is a user error! */
static const unsigned int INVALID_CITY_NUM = 0;

/**
    Data model for a city "node".

    For any given city (including the capitol), we store:
    1) the city IDs connected to this city
    2) the travel time it takes to travel to each adjacent city

    These are stored in arrays that the CityInfo objec has pointers to. Note
    that the number of elements in both of these arrays must be equal.

    Note that, to simplify message distribution/traversal, we never store the
    capitol as a connected city. This is because we can assume that messages
    are always sent from the capitol and messages will never find the 
    quicekest path by traveling back (or through) the capitol.

*/
typedef struct CityInfo
{
    unsigned int *  pConnectedIds;      /**< city IDs connected to this city */
    int *           pTravelTime;        /**< total travel times it takes to travel to each of the adjacent cities */
    unsigned int    numConnectedCities; /**< should not include connection to capitol city! */

} CityInfo;

#if defined(UNIT_TEST)
/** Basic performance stat maintainted during unit tests */
static unsigned int gSendMessageCount = 0;
#endif

/**
    The primary function used to traverse the empire and distribute messages.

    \param pCities Array of CityInfo structs that represent each city in the 
        empire.

    \param pMinPathTime Array of "minimum path length" values. Stores the
        lowest amount of time it takes for a message to reach a given city.

    \param currentCity The city that this message is being "delievered" to.

    \param travelTime The amount of time it took to deliver this message from
        where this message originated from.

    \param pVisitedCities Array of city IDs that we've already visited.

    \param totalTravelTime Total accumulated travel time for this message, 
        by value.
*/
static void sendMessage(
    CityInfo*           pCities,
    int *               pMinPathTime,
    const unsigned int  currentCity, 
    const int           travelTime, 
    unsigned int *      pVisitedCities, 
    int                 totalTravelTime)
{
    unsigned int lastVisitedCityIndex = 0;

#if defined(UNIT_TEST)
    /* For unit-tests, keep track of total times this function is called */
    gSendMessageCount++;
#endif

#if defined(DIAGNOSTIC_LOGGING)
    printf("Visiting %u\n", currentCity);
#endif

    for ( ; 0 != pVisitedCities[lastVisitedCityIndex]; ++lastVisitedCityIndex)
    {
        /* Ignore this city if this message has already been delivered here */
        if (currentCity == pVisitedCities[lastVisitedCityIndex])
        {
#if defined(DIAGNOSTIC_LOGGING)
            printf("Ignoring %u: already visited\n", currentCity);
#endif

            return;
        }
    }

    /* Add up the travel time */
    totalTravelTime += travelTime;

    if (totalTravelTime >= pMinPathTime[currentCity])
    {
        /* No point in continuing traversal as a longer path has already been
        discovered. */
        return;
    }

    /* We found a quicker path to the city */
    pMinPathTime[currentCity] = totalTravelTime;

    /* Record that we're visiting this city */
    pVisitedCities[lastVisitedCityIndex] = currentCity;

#if defined(DIAGNOSTIC_LOGGING)
    printf("pMinPathTime[%u] = %d\n", currentCity, totalTravelTime);
#endif

    /* Send the message to any other adjacent cities */
    for (unsigned int i = 0; i < pCities[currentCity].numConnectedCities; ++i)
    {
        sendMessage(
            pCities, 
            pMinPathTime, 
            pCities[currentCity].pConnectedIds[i], 
            pCities[currentCity].pTravelTime[i], 
            pVisitedCities, 
            totalTravelTime);
    }

    /* We're done visiting this city */
    pVisitedCities[lastVisitedCityIndex] = 0;
}

/**
    Initializes the "minimum path length" array.

    As a message is distributed throughout the capitol, we accumulate the
    total travel time along the path. When a message arrives at a city, we
    check the total travel time against this "minimum path length" array.
    If the travel time for the message is less than the value stored in this
    array (for this city), then store the new value in the array because we
    found a shorter path to distribute the message to this particular city.

    In order to "prime" for the aforementioned algorithm, we initialize each
    minimum path length for each city to INT_MAX, ensuring that a new minimum
    path length will always be assigned (unless the path length is actually
    INT_MAX, in which case the value stored in this array will be accurate
    anyways).
*/
static void initMinPathTimes(
    CityInfo *      pCities,
    int *           pMinPathTimes, 
    unsigned int    numCities)
{
    /* Capitol sending a message to itself will always be zero. */
    pMinPathTimes[CAPITOL_CITY] = 0;

    for (unsigned int i = 1; i < numCities; ++i)
    {
        pMinPathTimes[i] = INT_MAX;
    }

    /* Ugly special-case handling: find cities that are truly orphaned. A
    city can only be orphaned if it has no connections and the capitol isn't
    connected to it. Note that the capitol doesn't count as a connection to
    cities adjacent to the capitol. */
    for (unsigned int i = 1; i < numCities; ++i)
    {
        /* Look for cities with no adjacent cities */
        if (0 == pCities[i].numConnectedCities)
        {
            /* Next we check if the capitol is adjacent to it. */
            bool foundCapitolConnection = FALSE;
            for (unsigned int capitolIter = 0;
                capitolIter < pCities[CAPITOL_CITY].numConnectedCities;
                ++capitolIter)
            {
                if (i == pCities[CAPITOL_CITY].pConnectedIds[capitolIter])
                {
                    /* If the capitol is adjacent to the city, then it's not
                    orphaned. */
                    foundCapitolConnection = TRUE;
                    break;
                }
            }

            if (!foundCapitolConnection)
            {
                /* Found a city with zero adjacent cities and no capitol
                adjacency. This city is truly orphaned. In this case, set its
                min path length to zero. */
                pMinPathTimes[i] = 0;
            }
        }
    }
}

/**
    Returns the minimum amount of time it takes to distribute a message throughout the empire.
*/
static int minDistributionTime(
    CityInfo *          pCities, 
    const unsigned int  numCities)
{
    unsigned int    visitedCities[MAX_NUM_CITIES]   = { 0 };
    int             travelTime                      = 0;

    int             minPathTime[MAX_NUM_CITIES];
    initMinPathTimes(pCities, minPathTime, numCities);

    /* Special case: if only one city is specified, or there are no cities
    connected to the capitol, return zero */
    if (1 == numCities || 0 == pCities[CAPITOL_CITY].numConnectedCities)
    {
        return 0;
    }

    /* Begin message distribution by starting with the cities adjacent to the
    capitol. */
    for (unsigned int i = 0; i < pCities[CAPITOL_CITY].numConnectedCities; ++i)
    {
#if defined(DIAGNOSTIC_LOGGING)
        printf("--- Begin: city %u ---\n", pCities[CAPITOL_CITY].pConnectedIds[i]);
#endif

        sendMessage(
            pCities, 
            minPathTime, 
            pCities[CAPITOL_CITY].pConnectedIds[i], 
            pCities[CAPITOL_CITY].pTravelTime[i], 
            visitedCities, 
            travelTime);

#if defined(DIAGNOSTIC_LOGGING)
        printf("--- End: city %u ---\n", pCities[CAPITOL_CITY].pConnectedIds[i]);
#endif
    }

    /* pMinPathTime contains an array of the minimum path length for each
    city. To find how long it takes for a message to be distributed 
    throughout the empire we simply look for the longest path length in this
    array. */
    int longestTravelTime = INT_MIN;
    for (unsigned int i = 1; i < numCities; ++i)
    {
        if (longestTravelTime < minPathTime[i])
        {
            longestTravelTime = minPathTime[i];
        }
    }

    return longestTravelTime;
}

/**
    Queries stdin to determine the amount of cities in the empire.
*/
static const unsigned int getNumCitiesFromStdin()
{
    static const int    INVALID_NUM_CHARS_PARSED = 0;
    unsigned int        numCities = 0;
    int                 numParsedChars = scanf("%d", &numCities);

    /* Handle the following scenarios:
    1) we didn't parse valid input 
    2) the user specified zero cities
    3) user specified more cities than we support */
    if (INVALID_NUM_CHARS_PARSED == numParsedChars || INVALID_CITY_NUM == numCities || MAX_NUM_CITIES < numCities)
    {
        return INVALID_CITY_NUM;
    }

    return numCities;
}

/**
    Returns a linear (one dimensional) integer array of integer values from stdin.

    This is the lower triangular portion of the adjacency matrix parsed from 
    stdin. A zero travel value is used for inputs where 'x' is specified (to 
    indicate that there is no adjacency for the given cities).

    A city sending a message to itself (that is, the diagonal of the 
    adjacency matrix) has a travel time of zero. We assume that since it's
    impossible to specify the travel time of a city sending a message to 
    itself (since the user can only input the lower-triangular portion of the
    adjancency matrix), then zero can be used as a special-case value for
    representing no direct path between two given cities.
*/
static int * getParseBufferFromStdin(
    const unsigned int numCities,
    unsigned int * pParseBufferSize)
{
    /* 16 bytes is more than enough to parse an integer value string */
    char                tempCharBuffer[16]  = { 0 };
    const unsigned int  numBufferElements   = (numCities * (numCities - 1)) / 2;
    *pParseBufferSize                       = sizeof(int) * numBufferElements;
    unsigned int        parseIndex          = 0;
    int *               pParseBuffer        = malloc(*pParseBufferSize);
    unsigned int        numLinesToParse     = numCities - 1;

    while (numLinesToParse)
    {
        unsigned numLineValuesToParse = numCities - numLinesToParse;

        while (numLineValuesToParse)
        {
            int parsedTravelTime = 0;

            /* First read input into a char buffer to easily verify if 'x'
            has been provided. */
            scanf("%16s", tempCharBuffer);

            /* Special case: if cities aren't connected (represented by the
            character 'x'), define the travel time as zero. */
            if ('x' == tempCharBuffer[0])
            {
                parsedTravelTime = 0;
            }
            else
            {
                sscanf(tempCharBuffer, "%d", &parsedTravelTime);
            }

            /* Store the value and prime for the next parsed value */
            assert(parseIndex < numBufferElements);
            pParseBuffer[parseIndex] = parsedTravelTime;
            ++parseIndex;

            --numLineValuesToParse;
        }

        --numLinesToParse;
    }

    return pParseBuffer;
}

/**
    Sums number of adjacenct cities on a per-city basis based on input buffer.

    On a per-city basis, sums the number of connected cities. Unlike the
    given parse buffer (which only assumes a symmetric relationship), this 
    function takes the symmetric relatioship into account.

    However, the capitol is treated as a special case. Because messages are
    distributed from the capitol, and will never return to the capitol, we
    don't list the capitol as being adjacent to a city. However, the capitol
    itself will list all adjacent. We enforce this special case to make our 
    message distribution algorithm simpler.

    Although we could move the special-case to the message traversal 
    algorithm directly (that is, when performing message traversal, never
    send the message to the capitol, even if it's adjacent), we enforce this
    requirement here so that we never have to worry about distributing a
    message back to the capitol.

    \param pAdjacencyCounts An array that must be of at least numCities size.
        Memory for this is managed by the caller. This array is indexed by 
        city ID and stores the number of connected cities on a per-city 
        basis.

    \param numCities Parsed from stdin. Total number of cities, including the
        capitol.

    \param pParseBuffer The parsed int buffer from stdin.

    \return The total number of adjacent city relationships there are. This
        number includes symmetric relationships (which isn't specified in 
        given parse buffer).
*/
static unsigned int calculateCityAdjacencyCounts(
    unsigned int *      pAdjacencyCounts, 
    const unsigned int  numCities, 
    const int *         pParseBuffer)
{
    unsigned int totalAdjacencyCount = 0;

    /* We need a seperate index to iterate through the buffer */
    unsigned int parseBufferIndex = 0;

    for (unsigned int i = 1; i < numCities; ++i)
    {
        const int currentCity = i;

        for (unsigned int j = 0; j < i; ++j)
        {
            const int travelTime = pParseBuffer[parseBufferIndex];
            ++parseBufferIndex;

            /* If these cities aren't connected, then ignore */
            if (0 == travelTime)
            {
                continue;
            }

            const unsigned int connectedCity = j;

            /* Keep count of how many cities are adjacented to both of these
            cities. */
            ++(pAdjacencyCounts[connectedCity]);
            ++totalAdjacencyCount;

            /* Cities don't list the capitol as being adjacent (even if it
            is) because this simplifies our message traversal algorithm. Note
            that we only need to check if the connectCity is the capitol
            since our traversal prevents currentCity from being the capitol. */
            if (CAPITOL_CITY != connectedCity)
            {
                ++(pAdjacencyCounts[currentCity]);
                ++totalAdjacencyCount;
            }
        }
    }

    return totalAdjacencyCount;
}

/**
    Performs one-time allocation of resources for CityInfo objects.

    CityInfo objects contain two pointers: an array of adjacent city IDs and
    and array of travel values (the number of elements in both arrays should
    be equal so that they both correlate to each other).

    This function dynamically allocates the buffers that both of those 
    pointers will point to.

    \param pCities Array of CityInfo objects; defined for every city.

    \param numCities Total number of cities parsed.

    \param pConnectedIdsBuffer The buffer dynamically allocated by this 
        function for storing adjacent city connections for every city.

    \param pTravelTimeBuffer The buffer dynamically allocated by this
        function for storing the amount of travel time for all adjacent
        cities per-city.

    \param adjacencyCityCount An array that gives, per city, the number of
        adjacent city connections.

    \param totalAdjacencyCount The summed value of all values listed in 
        adjacencyCityCount.
*/
static void allocateCityInfoBuffers(
    CityInfo *              pCities,
    const unsigned int      numCities,
    unsigned int *          pConnectedIdsBuffer,
    int *                   pTravelTimeBuffer,
    const unsigned int *    adjacencyCityCount,
    const unsigned int      totalAdjacencyCount)
{
    /* Now that we know the total number of connected adjacent relationships
    amongst the cities, we can allocate buffers to store all of our
    relationship data and then populate it. */
    const unsigned int connectedIdsBufferSize   = sizeof(unsigned int) * totalAdjacencyCount;
    pConnectedIdsBuffer                         = malloc(connectedIdsBufferSize);
    memset(pConnectedIdsBuffer, 0, connectedIdsBufferSize);

    const unsigned int travelTimeBufferSize     = sizeof(int) * totalAdjacencyCount;
    pTravelTimeBuffer                           = malloc(travelTimeBufferSize);
    memset(pTravelTimeBuffer, 0, travelTimeBufferSize);

    /* As we iterate we need to keep track how far along we are in our
    buffers*/
    unsigned int bufferIndex = 0;

    /* Prime our iteration by manually assigning the beginning of our buffers
    to the first city. This is needed due to the way we need to know the
    number of elements in the buffer the previous city has consumed, however
    this information isn't relevent for the very first entry. */
    pCities[0].numConnectedCities   = adjacencyCityCount[0];
    pCities[0].pConnectedIds        = &(pConnectedIdsBuffer[0]);
    pCities[0].pTravelTime          = &(pTravelTimeBuffer[0]);

    for (unsigned int i = 1; i < numCities; ++i)
    {
        pCities[i].numConnectedCities = adjacencyCityCount[i];

        /* Move our index along the buffer by determing how much space the
        last city needed. */
        bufferIndex                 += adjacencyCityCount[i - 1];
        pCities[i].pConnectedIds    = &(pConnectedIdsBuffer[bufferIndex]);
        pCities[i].pTravelTime      = &(pTravelTimeBuffer[bufferIndex]);
    }
}

/**
    Adds one city to another as being connected, along with its travel time.

    \param pCities Array of all CityInfo objects for the entire empire.

    \param fromCity This city's connected city IDs and "travel time" array
        will be updated to point to the other city.

    \param toCity The city to connect to.

    \param travelTime Amount of travel time it takes to connect fromCity to toCity.
*/
static void connectSingleCity(
    CityInfo *          pCities,
    const unsigned int  fromCity,
    const unsigned int  toCity,
    const int           travelTime)
{
    bool alreadyConnected = FALSE;

    unsigned int lastCityIndex;

    /* Check if we already have connected these cities */
    for (lastCityIndex = 0; lastCityIndex < pCities[fromCity].numConnectedCities; ++lastCityIndex)
    {
        if (toCity == pCities[fromCity].pConnectedIds[lastCityIndex])
        {
            alreadyConnected = TRUE;
            break;
        }
        else if (0 == pCities[fromCity].pConnectedIds[lastCityIndex])
        {
            /* Since we never expect to see 0 as a connected city ID, we 
            assume that these are values that haven't been initialized yet. */
            break;
        }
    }

    if (!alreadyConnected && CAPITOL_CITY != toCity)
    {
        pCities[fromCity].pConnectedIds[lastCityIndex] = toCity;
        pCities[fromCity].pTravelTime[lastCityIndex] = travelTime;

#if defined(DIAGNOSTIC_LOGGING)
        printf("%u connected to %u (travel time: %d)\n", fromCity, toCity, travelTime);
#endif
    }
}

/**
    Ensures that both given cities are connected to each other.
*/
static void connectCities(
    CityInfo *          pCities, 
    const unsigned int  city1,
    const unsigned int  city2,
    const int           travelTime)
{
    connectSingleCity(pCities, city1, city2, travelTime);
    connectSingleCity(pCities, city2, city1, travelTime);
}

/**
    Creates the CityInfo objects from the parsed input buffer.
*/
static void populateCityInfo(
    CityInfo *          pCities, 
    const unsigned int  numCities, 
    const int *         pParseBuffer, 
    unsigned int *      pConnectedIdsBuffer, 
    int *               pTravelTimeBuffer)
{
    unsigned int adjacencyCityCount[MAX_NUM_CITIES] = { 0 };
    unsigned int totalAdjacencyCount                = 0;

    totalAdjacencyCount = calculateCityAdjacencyCounts(adjacencyCityCount, numCities, pParseBuffer);

    allocateCityInfoBuffers(pCities, numCities, pConnectedIdsBuffer, pTravelTimeBuffer, adjacencyCityCount, totalAdjacencyCount);

    /* We need a seperate index to iterate through the buffer */
    unsigned int parseBufferIndex = 0;

    for (unsigned int i = 1; i < numCities; ++i)
    {
        for (unsigned int j = 0; j < i; ++j)
        {
            const int travelTime = pParseBuffer[parseBufferIndex];
            ++parseBufferIndex;

            /* If these cities aren't connected, then ignore */
            if (0 == travelTime)
            {
                continue;
            }

            connectCities(pCities, i, j, travelTime);
        }
    }
}

#if defined(UNIT_TEST)
static void unitTest()
{
#if defined(STDIN_PARSE_BUFFER_MANUAL_TEST)
    {
        int pParseBuffer[10] =
        {
            50,
            30, 5,
            100, 20, 50,
            10, 0, 0, 10
        };
        const unsigned int parseBufferSize = sizeof(pParseBuffer);

        unsigned int otherBufferSize = 0;
        int * pAnotherParseBuffer = getParseBufferFromStdin(5, &otherBufferSize);

        assert(parseBufferSize == otherBufferSize);

        for (unsigned int i = 0; i < 10; ++i)
        {
            assert(pParseBuffer[i] == pAnotherParseBuffer[i]);
        }

        assert(0 == memcmp(pParseBuffer, pAnotherParseBuffer, parseBufferSize));
        free(pAnotherParseBuffer);
    }
#endif
    {
        /* Given example unit-test */
        CityInfo            cities[MAX_NUM_CITIES];

        unsigned int *      pConnectedIdsBuffer = 0;
        int *               pTravelTimeBuffer = 0;
        unsigned int        numCities = 5;

        int pParseBuffer[10] =
        {
            50,
            30, 5,
            100, 20, 50,
            10, 0, 0, 10
        };

        populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);

        for (unsigned int i = 0; i < numCities; ++i)
        {
            printf("Connection info for %d: ", i);
            for (unsigned int j = 0; j < cities[i].numConnectedCities; ++j)
            {
                printf("(%d, %d), ", cities[i].pConnectedIds[j], cities[i].pTravelTime[j]);
            }
            printf("\n");
        }

        const int minTime = minDistributionTime(cities, numCities);
        assert(35 == minTime);
        free(pConnectedIdsBuffer);
        free(pTravelTimeBuffer);
    }
    {
        /* Only one city */
        CityInfo            cities[MAX_NUM_CITIES];
        unsigned int *      pConnectedIdsBuffer = 0;
        int *               pTravelTimeBuffer = 0;
        unsigned int        numCities = 1;
        /* Doesn't really matter what's in our parse buffer since we're only
        specifying one city. */
        int pParseBuffer[10] =
        {
            50,
            30, 5,
            100, 20, 50,
            10, 0, 0, 10
        };
        populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);
        const int minTime = minDistributionTime(cities, numCities);
        assert(0 == minTime);
        free(pConnectedIdsBuffer);
        free(pTravelTimeBuffer);
    }
    {
        /* Multiple cities, all orphaned */
        CityInfo            cities[MAX_NUM_CITIES];
        unsigned int *      pConnectedIdsBuffer = 0;
        int *               pTravelTimeBuffer = 0;
        unsigned int        numCities = 2;
        int pParseBuffer[1] =
        {
            0
        };
        populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);
        const int minTime = minDistributionTime(cities, numCities);
        assert(0 == minTime);
        free(pConnectedIdsBuffer);
        free(pTravelTimeBuffer);
    }
    {
        /* Multiple cities, all orphaned */
        CityInfo            cities[MAX_NUM_CITIES];
        unsigned int *      pConnectedIdsBuffer = 0;
        int *               pTravelTimeBuffer = 0;
        unsigned int        numCities = 3;
        int pParseBuffer[3] =
        {
            0,
            0, 0
        };
        populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);
        const int minTime = minDistributionTime(cities, numCities);
        assert(0 == minTime);
        free(pConnectedIdsBuffer);
        free(pTravelTimeBuffer);
    }
    {
        /* Multiple cities, orphaned from capitol */
        CityInfo            cities[MAX_NUM_CITIES];
        unsigned int *      pConnectedIdsBuffer = 0;
        int *               pTravelTimeBuffer = 0;
        unsigned int        numCities = 3;
        int pParseBuffer[3] =
        {
            0,
            0, 1
        };
        populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);
        const int minTime = minDistributionTime(cities, numCities);
        assert(0 == minTime);
        free(pConnectedIdsBuffer);
        free(pTravelTimeBuffer);
    }
    {
        /* Multiple cities, orphaned from capitol */
        CityInfo            cities[MAX_NUM_CITIES];
        unsigned int *      pConnectedIdsBuffer = 0;
        int *               pTravelTimeBuffer = 0;
        unsigned int        numCities = 5;
        int pParseBuffer[10] =
        {
            0,
            0, 5,
            0, 20, 50,
            0, 1, 1, 10
        };
        populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);
        const int minTime = minDistributionTime(cities, numCities);
        assert(0 == minTime);
        free(pConnectedIdsBuffer);
        free(pTravelTimeBuffer);
    }
    {
        CityInfo            cities[MAX_NUM_CITIES];
        unsigned int *      pConnectedIdsBuffer = 0;
        int *               pTravelTimeBuffer = 0;
        unsigned int        numCities = 2;
        int pParseBuffer[1] =
        {
            1
        };
        populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);
        const int minTime = minDistributionTime(cities, numCities);
        assert(1 == minTime);
        free(pConnectedIdsBuffer);
        free(pTravelTimeBuffer);
    }
    {
        CityInfo            cities[MAX_NUM_CITIES];
        unsigned int *      pConnectedIdsBuffer = 0;
        int *               pTravelTimeBuffer = 0;
        unsigned int        numCities = 2;
        int pParseBuffer[1] =
        {
            2
        };
        populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);
        const int minTime = minDistributionTime(cities, numCities);
        assert(2 == minTime);
        free(pConnectedIdsBuffer);
        free(pTravelTimeBuffer);
    }
    {
        CityInfo            cities[MAX_NUM_CITIES];
        unsigned int *      pConnectedIdsBuffer = 0;
        int *               pTravelTimeBuffer = 0;
        unsigned int        numCities = 3;
        int pParseBuffer[3] =
        {
            1,
            1, 0
        };
        populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);
        const int minTime = minDistributionTime(cities, numCities);
        assert(1 == minTime);
        free(pConnectedIdsBuffer);
        free(pTravelTimeBuffer);
    }
    {
        /* 100 simple stress test: all cities are connected only to the 
        capitol and all have the same travel time. */
        CityInfo            cities[MAX_NUM_CITIES];
        unsigned int *      pConnectedIdsBuffer = 0;
        int *               pTravelTimeBuffer = 0;
        unsigned int        numCities = 100;
        const unsigned int  parseBufferSize = sizeof(int) * ((numCities*(numCities - 1)) / 2);
        int * pParseBuffer = malloc(parseBufferSize);
        memset(pParseBuffer, 0, parseBufferSize);
        unsigned int parseBufferIndex = 0;
        for (unsigned int i = 1; i < numCities; ++i)
        {
            pParseBuffer[parseBufferIndex] = 1;
            for (unsigned int j = 0; j < i; ++j)
            {
                ++parseBufferIndex;
            }
        }
        populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);
        free(pParseBuffer);
        const int minTime = minDistributionTime(cities, numCities);
        assert(1 == minTime);
        free(pConnectedIdsBuffer);
        free(pTravelTimeBuffer);
    }

#define HEAVY_TEST(NUM_CITIES)                                                                      \
    {                                                                                               \
        /* 100 city test */                                                                         \
        CityInfo            cities[MAX_NUM_CITIES];                                                 \
        unsigned int *      pConnectedIdsBuffer = 0;                                                \
        int *               pTravelTimeBuffer = 0;                                                  \
        unsigned int        numCities = NUM_CITIES;                                                 \
        const unsigned int  totalParseEntries = ((numCities*(numCities - 1)) / 2);                  \
        const unsigned int  parseBufferSize = sizeof(int) * totalParseEntries;                      \
        int * pParseBuffer = malloc(parseBufferSize);                                               \
        memset(pParseBuffer, 0, parseBufferSize);                                                   \
        unsigned int parseBufferIndex = 0;                                                          \
        for (unsigned int i = 1; i < numCities; ++i)                                                \
        {                                                                                           \
            pParseBuffer[parseBufferIndex] = 1;                                                     \
            assert(parseBufferIndex < totalParseEntries);                                           \
            for (unsigned int j = 0; j < i; ++j)                                                    \
            {                                                                                       \
                ++parseBufferIndex;                                                                 \
                if (parseBufferIndex < totalParseEntries)                                           \
                {                                                                                   \
                    pParseBuffer[parseBufferIndex] = 1;                                             \
                }                                                                                   \
            }                                                                                       \
        }                                                                                           \
        populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);  \
        free(pParseBuffer);                                                                         \
        gSendMessageCount = 0;                                                                      \
        const int minTime = minDistributionTime(cities, numCities);                                 \
        assert(1 == minTime);                                                                       \
        printf("Num cities = %u, send message called %u times.\n", numCities, gSendMessageCount);   \
        free(pConnectedIdsBuffer);                                                                  \
        free(pTravelTimeBuffer);                                                                    \
    }

    HEAVY_TEST(2);
    HEAVY_TEST(3);
    HEAVY_TEST(4);
    HEAVY_TEST(5);
    HEAVY_TEST(6);
    HEAVY_TEST(7);
    HEAVY_TEST(8);
    HEAVY_TEST(9);
    HEAVY_TEST(10);
    HEAVY_TEST(11);
    HEAVY_TEST(12);
    HEAVY_TEST(13);
    HEAVY_TEST(14);
    HEAVY_TEST(15);
    HEAVY_TEST(16);
    HEAVY_TEST(17);
    HEAVY_TEST(18);
    HEAVY_TEST(19);
    HEAVY_TEST(20);
    HEAVY_TEST(21);
    HEAVY_TEST(22);
    HEAVY_TEST(23);
    HEAVY_TEST(24);
    HEAVY_TEST(25);
    HEAVY_TEST(26);
    HEAVY_TEST(27);
    HEAVY_TEST(28);
    HEAVY_TEST(29);
    HEAVY_TEST(30);
    HEAVY_TEST(31);
    HEAVY_TEST(32);
    HEAVY_TEST(33);
    HEAVY_TEST(34);
    HEAVY_TEST(35);
    HEAVY_TEST(36);
    HEAVY_TEST(37);
    HEAVY_TEST(38);
    HEAVY_TEST(39);
    HEAVY_TEST(40);
    HEAVY_TEST(41);
    HEAVY_TEST(42);
    HEAVY_TEST(43);
    HEAVY_TEST(44);
    HEAVY_TEST(45);
    HEAVY_TEST(46);
    HEAVY_TEST(47);
    HEAVY_TEST(48);
    HEAVY_TEST(49);
    HEAVY_TEST(50);
    HEAVY_TEST(51);
    HEAVY_TEST(52);
    HEAVY_TEST(53);
    HEAVY_TEST(54);
    HEAVY_TEST(55);
    HEAVY_TEST(56);
    HEAVY_TEST(57);
    HEAVY_TEST(58);
    HEAVY_TEST(59);
    HEAVY_TEST(60);
    HEAVY_TEST(61);
    HEAVY_TEST(62);
    HEAVY_TEST(63);
    HEAVY_TEST(64);
    HEAVY_TEST(65);
    HEAVY_TEST(66);
    HEAVY_TEST(67);
    HEAVY_TEST(68);
    HEAVY_TEST(69);
    HEAVY_TEST(70);
    HEAVY_TEST(71);
    HEAVY_TEST(72);
    HEAVY_TEST(73);
    HEAVY_TEST(74);
    HEAVY_TEST(75);
    HEAVY_TEST(76);
    HEAVY_TEST(77);
    HEAVY_TEST(78);
    HEAVY_TEST(79);
    HEAVY_TEST(80);
    HEAVY_TEST(81);
    HEAVY_TEST(82);
    HEAVY_TEST(83);
    HEAVY_TEST(84);
    HEAVY_TEST(85);
    HEAVY_TEST(86);
    HEAVY_TEST(87);
    HEAVY_TEST(88);
    HEAVY_TEST(89);
    HEAVY_TEST(90);
    HEAVY_TEST(91);
    HEAVY_TEST(92);
    HEAVY_TEST(93);
    HEAVY_TEST(94);
    HEAVY_TEST(95);
    HEAVY_TEST(96);
    HEAVY_TEST(97);
    HEAVY_TEST(98);
    HEAVY_TEST(99);
    HEAVY_TEST(100);

#undef HEAVY_TEST

    {
        /* 100 city test: every city is connected to capitol and each city's
        number/ID is it's travel weight, however, all of the cities are
        connected to each-other with an extremely fast travel time of 1,
        so the max travel is only 2 since all traffic can be routed through
        the first city and deliver via the fast connected path. */
        CityInfo            cities[MAX_NUM_CITIES];
        unsigned int *      pConnectedIdsBuffer = 0;
        int *               pTravelTimeBuffer = 0;
        unsigned int        numCities = 100;
        const unsigned int  totalParseEntries = ((numCities*(numCities - 1)) / 2);
        const unsigned int  parseBufferSize = sizeof(int) * totalParseEntries;
        int * pParseBuffer = malloc(parseBufferSize);
        memset(pParseBuffer, 0, parseBufferSize);
        unsigned int parseBufferIndex = 0;
        for (unsigned int i = 1; i < numCities; ++i)
        {
            pParseBuffer[parseBufferIndex] = i;
            assert(parseBufferIndex < totalParseEntries);
            for (unsigned int j = 0; j < i; ++j)
            {
                ++parseBufferIndex;
                if (parseBufferIndex < totalParseEntries)
                {
                    pParseBuffer[parseBufferIndex] = 1;
                }
            }
        }
        populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);
        free(pParseBuffer);
        gSendMessageCount = 0;
        const int minTime = minDistributionTime(cities, numCities);
        assert(2 == minTime);
        printf("Num cities = %u, send message called %u times.\n", numCities, gSendMessageCount);
        free(pConnectedIdsBuffer);
        free(pTravelTimeBuffer);
    }
    {
        for (unsigned int numCityIter = 1; numCityIter <= 100; ++numCityIter)
        {
            /* 100 city test: all cities are connected to the capitol and
            their travel time is equivalent to the city's ID/number, and all
            cities are interconnected to each-other via an expensive travel
            time, so it's faster to get messages directly from the capitol. */
            CityInfo            cities[MAX_NUM_CITIES];
            unsigned int *      pConnectedIdsBuffer = 0;
            int *               pTravelTimeBuffer = 0;
            unsigned int        numCities = numCityIter;
            const unsigned int  totalParseEntries = ((numCities*(numCities - 1)) / 2);
            const unsigned int  parseBufferSize = sizeof(int) * totalParseEntries;
            int * pParseBuffer = malloc(parseBufferSize);
            memset(pParseBuffer, 0, parseBufferSize);
            unsigned int parseBufferIndex = 0;
            for (unsigned int i = 1; i < numCities; ++i)
            {
                pParseBuffer[parseBufferIndex] = i;
                assert(parseBufferIndex < totalParseEntries);
                for (unsigned int j = 0; j < i; ++j)
                {
                    ++parseBufferIndex;
                    if (parseBufferIndex < totalParseEntries)
                    {
                        pParseBuffer[parseBufferIndex] = 100;
                    }
                }
            }
            populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);
            free(pParseBuffer);
            gSendMessageCount = 0;
            const int minTime = minDistributionTime(cities, numCities);
            assert((int)(numCityIter - 1) == minTime);
            printf("Num cities = %u, send message called %u times.\n", numCities, gSendMessageCount);
            free(pConnectedIdsBuffer);
            free(pTravelTimeBuffer);
        }
    }
    {
        for (unsigned int numCityIter = 1; numCityIter <= 100; ++numCityIter)
        {
            /* 100 city test: all cities are connected to the capitol with
            travel times equal to their city ID/number. All cities are
            interconnected to eachother with varying travel times, except
            the first city, which is always 1, which means all traffic can
            be routed through the first city yielding a total distribution
            time of 2. */
            CityInfo            cities[MAX_NUM_CITIES];
            unsigned int *      pConnectedIdsBuffer = 0;
            int *               pTravelTimeBuffer = 0;
            unsigned int        numCities = numCityIter;
            const unsigned int  totalParseEntries = ((numCities*(numCities - 1)) / 2);
            const unsigned int  parseBufferSize = sizeof(int) * totalParseEntries;
            int * pParseBuffer = malloc(parseBufferSize);
            memset(pParseBuffer, 0, parseBufferSize);
            unsigned int parseBufferIndex = 0;
            for (unsigned int i = 1; i < numCities; ++i)
            {
                pParseBuffer[parseBufferIndex] = i;
                assert(parseBufferIndex < totalParseEntries);

#if defined(DIAGNOSTIC_LOGGING)
                printf("%d ", pParseBuffer[parseBufferIndex]);
#endif

                ++parseBufferIndex;

                for (unsigned int j = 1; j < i; ++j)
                {
                    assert(parseBufferIndex < totalParseEntries);
                    pParseBuffer[parseBufferIndex] = j;

#if defined(DIAGNOSTIC_LOGGING)
                    printf("%d ", pParseBuffer[parseBufferIndex]);
#endif

                    ++parseBufferIndex;
                }

#if defined(DIAGNOSTIC_LOGGING)
                printf("\n");
#endif
            }
            populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);
            free(pParseBuffer);
            gSendMessageCount = 0;
            const int minTime = minDistributionTime(cities, numCities);
            if (numCities > 2)
            {
                assert(2 == minTime);
            }
            else if (numCities == 1)
            {
                assert(0 == minTime);
            }
            else if (numCities == 2)
            {
                assert(1 == minTime);
            }
            else
            {
                /* We should never hit this condition! */
                assert(0);
            }
            printf("Num cities = %u, send message called %u times.\n", numCities, gSendMessageCount);
            free(pConnectedIdsBuffer);
            free(pTravelTimeBuffer);
        }
    }
    {
        for (unsigned int numCityIter = 3; numCityIter <= 100; ++numCityIter)
        {
            /* 100 city test: only the first city is connected to the capitol
            and all other cities are connected to the first city. */
            CityInfo            cities[MAX_NUM_CITIES];
            unsigned int *      pConnectedIdsBuffer = 0;
            int *               pTravelTimeBuffer = 0;
            unsigned int        numCities = numCityIter;
            const unsigned int  totalParseEntries = ((numCities*(numCities - 1)) / 2);
            const unsigned int  parseBufferSize = sizeof(int) * totalParseEntries;
            int * pParseBuffer = malloc(parseBufferSize);
            memset(pParseBuffer, 0, parseBufferSize);
            unsigned int parseBufferIndex = 0;
            for (unsigned int i = 1; i < numCities; ++i)
            {
                if (i > 1)
                {
                    pParseBuffer[parseBufferIndex] = 0;
                }
                else
                {
                    /* Only the first city is connected to the capitol */
                    pParseBuffer[parseBufferIndex] = 1;
                }
                assert(parseBufferIndex < totalParseEntries);
                for (unsigned int j = 0; j < i; ++j)
                {
                    ++parseBufferIndex;
                    if (parseBufferIndex < totalParseEntries)
                    {
                        pParseBuffer[parseBufferIndex] = 1;
                    }
                }
            }
            populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);
            free(pParseBuffer);
            gSendMessageCount = 0;
            const int minTime = minDistributionTime(cities, numCities);
            assert(2 == minTime);
            printf("Num cities = %u, send message called %u times.\n", numCities, gSendMessageCount);
            free(pConnectedIdsBuffer);
            free(pTravelTimeBuffer);
        }
    }
    {
        for (unsigned int numCityIter = 3; numCityIter <= 100; ++numCityIter)
        {
            /* 100 city test: only the last city is connected to the capitol
            and all other cities are connected to the first city. */
            CityInfo            cities[MAX_NUM_CITIES];
            unsigned int *      pConnectedIdsBuffer = 0;
            int *               pTravelTimeBuffer = 0;
            unsigned int        numCities = numCityIter;
            const unsigned int  totalParseEntries = ((numCities*(numCities - 1)) / 2);
            const unsigned int  parseBufferSize = sizeof(int) * totalParseEntries;
            int * pParseBuffer = malloc(parseBufferSize);
            memset(pParseBuffer, 0, parseBufferSize);
            unsigned int parseBufferIndex = 0;
            for (unsigned int i = 1; i < numCities; ++i)
            {
                if (i < numCities-1)
                {
                    pParseBuffer[parseBufferIndex] = 0;
                }
                else
                {
                    /* Only the last city is connected to the capitol */
                    pParseBuffer[parseBufferIndex] = 1;
                }
                assert(parseBufferIndex < totalParseEntries);
                for (unsigned int j = 0; j < i; ++j)
                {
                    ++parseBufferIndex;
                    if (parseBufferIndex < totalParseEntries)
                    {
                        pParseBuffer[parseBufferIndex] = 1;
                    }
                }
            }
            populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);
            free(pParseBuffer);
            gSendMessageCount = 0;
            const int minTime = minDistributionTime(cities, numCities);
            assert(2 == minTime);
            printf("Num cities = %u, send message called %u times.\n", numCities, gSendMessageCount);
            free(pConnectedIdsBuffer);
            free(pTravelTimeBuffer);
        }
    }
    {
        CityInfo            cities[MAX_NUM_CITIES];
        unsigned int *      pConnectedIdsBuffer = 0;
        int *               pTravelTimeBuffer = 0;
        unsigned int        numCities = 3;
        int pParseBuffer[3] =
        {
            1,
            0, 1
        };
        populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);
        const int minTime = minDistributionTime(cities, numCities);
        assert(2 == minTime);
        free(pConnectedIdsBuffer);
        free(pTravelTimeBuffer);
    }
    {
        CityInfo            cities[MAX_NUM_CITIES];
        unsigned int *      pConnectedIdsBuffer = 0;
        int *               pTravelTimeBuffer = 0;
        unsigned int        numCities = 5;
        int pParseBuffer[12] =
        {
            1,
            0, 1,
            0, 0, 1,
            0, 0, 0, 1
        };
        populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);
        const int minTime = minDistributionTime(cities, numCities);
        assert(4 == minTime);
        free(pConnectedIdsBuffer);
        free(pTravelTimeBuffer);
    }
    {
        CityInfo            cities[MAX_NUM_CITIES];
        unsigned int *      pConnectedIdsBuffer = 0;
        int *               pTravelTimeBuffer = 0;
        unsigned int        numCities = 5;
        int pParseBuffer[12] =
        {
            1,
            0, 1,
            0, 0, 1,
            0, 0, 0, 0
        };
        populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);
        const int minTime = minDistributionTime(cities, numCities);
        assert(3 == minTime);
        free(pConnectedIdsBuffer);
        free(pTravelTimeBuffer);
    }
}
#endif

int main(int argc, char* argv [])
{
#if defined(UNIT_TEST)
    unitTest();
#endif

    CityInfo            cities[MAX_NUM_CITIES];

    unsigned int *      pConnectedIdsBuffer         = 0;
    int *               pTravelTimeBuffer           = 0;

    const unsigned int  numCities                   = getNumCitiesFromStdin();

    if (INVALID_CITY_NUM == numCities)
    {
        /* Invalid number of cities specified */
        printf("0");
        return 0;
    }

    unsigned int        parseBufferSize             = 0;
    int *               pParseBuffer                = getParseBufferFromStdin(numCities, &parseBufferSize);

    populateCityInfo(cities, numCities, pParseBuffer, pConnectedIdsBuffer, pTravelTimeBuffer);
    free(pParseBuffer);

    const int minTime = minDistributionTime(cities, numCities);
    printf("%d", minTime);

    /* We don't need city data anymore, so free it  */
    free(pConnectedIdsBuffer);
    free(pTravelTimeBuffer);

    return 0;
}