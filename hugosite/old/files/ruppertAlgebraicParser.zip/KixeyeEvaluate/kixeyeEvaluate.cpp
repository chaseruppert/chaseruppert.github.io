/**
 *  Chase Ruppert (chase.ruppert@live.com)
 *  KIXEYE Engineer Test
 *  8/20/2014
 */

#include "KixExpressionLib/kixExpression.h"
#include <cstdio>

int main( int argc, char *argv[] )
{
#if defined(UNIT_TEST)
    KixExpressionLib::UnitTest();
#endif
    
    const char * expression = "1+1";
    const float result = KixExpressionLib::Evaluate( expression );
    printf ( "%s = %f\n", expression, result );
    return 0;
}
