solution "kixeyeEvaluate"

    configurations { 
        "Debug",
        "Release",
    }

    -- For now we only support 32-bit platforms
    platforms { "x32" }
	
    location "../build/KixeyeEvaluate"
    
    flags { "FatalWarnings", "ExtraWarnings" }
    
    -- Windows builds
    configuration { "Debug", "vs2012" }
        defines { "_DEBUG", "UNIT_TEST" }
        flags { "Symbols" }
        buildoptions { "/wd\"4996\"", "/wd\"4100\"", "/wd\"4505\"", "/wd\"4206\"", "/wd\"4127\"", "/wd\"4244\"" }
        targetsuffix "d"
    
    configuration { "Release", "vs2012" }
        defines { "NDEBUG" }
        flags { "Symbols" }
        buildoptions { "/wd\"4996\"", "/wd\"4100\"", "/wd\"4505\"", "/wd\"4206\"", "/wd\"4127\"", "/wd\"4244\"" }

    -- OSX Builds
    configuration { "Debug", "xcode4" }
        defines { "_DEBUG", "UNIT_TEST" }
        flags { "Symbols" }
        targetsuffix "d"

    configuration { "Release", "xcode4" }
        defines { "NDEBUG" }
 
    -- A project defines one build target
    project "kixeyeEvaluate"
        kind "ConsoleApp"
        language "C++"
        
		debugLibs = {
            "KixExpressionLibd",
        }

		releaseLibs = {
            "KixExpressionLib",
        }

        
        includedirs {
            "../KixExpressionLib/include",
        }
      
        files { 
            
            "*.h", 
            "*.cpp", 
            "*.c",
            
        }
        
        libdirs {
			"../build/KixExpressionLib/lib/"
        }

        -- Windows builds 
        configuration { "Debug", "vs2012" }
            targetdir "../build/KixeyeEvaluate/bin"
            debugdir "."
			links { debugLibs }
            
        configuration { "Release", "vs2012" }
            targetdir "../build/KixeyeEvaluate/bin"
            debugdir "."
			links { releaseLibs }

        -- OSX Builds
        configuration { "Debug", "xcode4" }
            targetdir "../build/KixeyeEvaluate/bin"
            debugdir "."
			links { debugLibs }

        configuration { "Release", "xcode4" }
            targetdir "../build/KixeyeEvaluate/bin"
            debugdir "."
			links { releaseLibs }

        -- The KixExpressionLib library project
        include "../KixExpressionLib"
