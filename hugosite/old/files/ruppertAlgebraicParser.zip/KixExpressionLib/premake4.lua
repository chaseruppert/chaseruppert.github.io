project "KixExpressionLib"
    kind "StaticLib"
    language "C++"
    
    local buildPath = "../build/KixExpressionLib/"
    local libDirName = "lib"
    
    includedirs 
    {
        "include"
    }
  
    files { 
        "include/**.h", 
        "src/**.cpp", 
        "src/**.c"
    }
   
    -- Windows builds 
    configuration { "Debug", "vs2012" }
        targetdir( buildPath .. libDirName )
        debugdir "."
        
    configuration { "Release", "vs2012" }
        targetdir( buildPath .. libDirName )
        debugdir "."
        
    -- OSX Builds
    configuration { "Debug", "xcode4" }
        targetdir( buildPath .. libDirName )
        debugdir "."

    configuration { "Release", "xcode4" }
        targetdir( buildPath .. libDirName )
        debugdir "."
