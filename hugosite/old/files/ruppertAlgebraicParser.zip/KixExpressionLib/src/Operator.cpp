/*! \file Operator

    \brief Implementation of Operator class.

    \author Chase Ruppert (chase.ruppert@live.com)
*/

#include "KixExpressionLib/Operator.h"
#include <cmath>
#include <utility>

namespace
{
    
typedef std::pair<float, float> FloatPair;
    
FloatPair evaluateOperands(const KixExpressionLib::Expression* pExpression)
{
    FloatPair result;
    
    result.first = pExpression->EvaluateOperand(KixExpressionLib::Expression::FIRST);
    
    result.second = pExpression->EvaluateOperand(KixExpressionLib::Expression::SECOND);
    
    if (isnan(result.first) || isnan(result.second))
    {
        result.first = 0.0f;
        result.second = 0.0f;
    }
    
    return result;
}
    
}

const float KixExpressionLib::AdditionOperator::apply(const Expression* pExpression) const
{
    FloatPair evalResult = evaluateOperands(pExpression);
    return evalResult.first + evalResult.second;
}

const float KixExpressionLib::SubtractionOperator::apply(const Expression* pExpression) const
{
    FloatPair evalResult = evaluateOperands(pExpression);
    return evalResult.first - evalResult.second;
}

const float KixExpressionLib::MultiplicationOperator::apply(const Expression* pExpression) const
{
    FloatPair evalResult = evaluateOperands(pExpression);
    return evalResult.first * evalResult.second;
}

const float KixExpressionLib::DivisionOperator::apply(const Expression* pExpression) const
{
    FloatPair evalResult = evaluateOperands(pExpression);
    
    // Handle divide-by-zero by returning zero
    if (0.0f == evalResult.second)
    {
        return 0.0f;
    }
    
    return evalResult.first / evalResult.second;
}