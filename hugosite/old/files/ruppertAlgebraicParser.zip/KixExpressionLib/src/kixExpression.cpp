/*! \file kixExpression.cpp

    \brief Implementation of KixExpressionLib public interface.

    \author Chase Ruppert (chase.ruppert@live.com)
*/

#include "KixExpressionLib/kixExpression.h"
#include "KixExpressionLib/Expression.h"

#include <algorithm>
#include <cassert>

#if defined(_DEBUG)
#define VERBOSE_LOGGING 0
#endif

namespace
{
    
/// \brief Performs basic sanity checks on given expression string
/// \return true if expression seems sane, false otherwise.
bool sanityCheckOk(std::string expressionStr)
{
    size_t numOpenParens = std::count(expressionStr.begin(), expressionStr.end(), '(');
    size_t numCloseParens = std::count(expressionStr.begin(), expressionStr.end(), ')');
    
    return numOpenParens == numCloseParens;
}
    
}

/// \return Numerical result of evaluating the given string representation
/// of a mathematical expression.
const float KixExpressionLib::Evaluate(const char* pExpression)
{
    if (!sanityCheckOk(pExpression))
    {
        printf("Invalid expression!\n");
        return 0.0f;
    }
    
#if VERBOSE_LOGGING
    float result = Expression(pExpression).Evaluate();
    printf("Result: %f", result);
    return result;
#else
    return Expression(pExpression).Evaluate();
#endif
}

#if defined( UNIT_TEST )

/// \brief  Executes unit-tests against the library.
void KixExpressionLib::UnitTest()
{
    assert(2.0f == Evaluate("1+1"));
    assert(1.0f == Evaluate("2-1"));
    assert(-1.0f == Evaluate("2-3"));
    assert(6.0f == Evaluate("2*3"));
    assert(0.5f == Evaluate("1/2"));
    assert(0.0f == Evaluate("1/0"));
    assert(102.0f == Evaluate("2+25*4"));
    assert(31.0f == Evaluate("2+25+4"));
    assert(108.0f == Evaluate("2+25*4+6"));
    assert(108.0f == Evaluate("(2+25)*4"));
    assert(108.0f == Evaluate("((2+25)*4)"));
    assert(0.75f == Evaluate("54/((2+25)*4)+0.25"));
    assert(3.0f == Evaluate("(1)+(2)"));
    assert(5.0f == Evaluate("3/((1)+(2))*4+1"));
    assert(5.0f == Evaluate("(3/((1)+(2))*4+1)"));
    assert(9.0f == Evaluate("((3-1)*3/((1)+(2))*4+1)"));
    assert(7.0f == Evaluate("12*0.5-0.5+1.5"));
    assert(1.0f == Evaluate("12*(0.5-0.5)+1.5-0.5"));
    
    // Invalid
    assert(0.0f == Evaluate("1+*)/2"));
    assert(0.0f == Evaluate("((1+2)"));
    assert(0.0f == Evaluate("/2*(3-1)*"));
    assert(0.0f == Evaluate("("));
    assert(0.0f == Evaluate(")"));
    assert(0.0f == Evaluate("+*-/"));
    
    // Invalid ???
    assert(0.0f == Evaluate(""));
    assert(0.0f == Evaluate("()"));
}

#endif // #if defined( UNIT_TEST )