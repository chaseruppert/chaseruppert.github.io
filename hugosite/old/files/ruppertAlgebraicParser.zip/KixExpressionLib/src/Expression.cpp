/*! \file Expression.cpp

    \brief Implementation of Expression class.

    \author Chase Ruppert (chase.ruppert@live.com)
*/

#include "KixExpressionLib/Expression.h"
#include "KixExpressionLib/Operator.h"
#include <cstdio>
#include <climits>
#include <cmath>
#include <cassert>

namespace
{

/// \note Assumes the given expression string isn't enclosed in parentheses.
int leastPrecedenceOperatorIndex(const std::string& expressionStr)
{
    //assert(!hasEnclosingParentheses(expressionStr));
    
    static const int UNINITIALIZED = -1;
    
    // The index of the operator of least precedence for the given expression
    // string.
    int operatorIndex = UNINITIALIZED;
    
    // Since we're assuming the given expression itself isn't entirely enclosed
    // in parentheses, then the least precedent operator must exist outside of
    // parentheses within the expression. Based on that assumption, we'll skip
    // content enclosed in parentheses (if any) using this variable.
    unsigned int parenBlockCount = 0;
    
    // The resulting expression needs to be evaluated left-to-right, but our
    // expression "tree" evaluates the "deepest" nodes first. Therefore, we
    // need to iterate in reverse order so that the right-most expressions
    // are placed at the top of the tree (and evaluated last).
    std::string::const_reverse_iterator citr;
    for (citr = expressionStr.rbegin(); citr != expressionStr.rend(); ++citr)
    {
        const char currentChar = *citr;
        
        // Skip any opening or closing parenthesis, and anything in between.
        // Since we're iterating in reverse, closing parenthesis add to the
        // block count, while opening will decrease it. A positive block count
        // value means we're currently in a parentheses-enclosed expression.
        if ('(' == currentChar)
        {
            parenBlockCount--;
            continue;
        }
        else if (')' == currentChar)
        {
            parenBlockCount++;
            continue;
        }
        else if (0 < parenBlockCount)
        {
            continue;
        }
        
        // Since addition and subtraction are the lowest precedent
        // operators, if we find one outside of parentheses, then
        // we're done.
        if ('+' == currentChar || '-' == currentChar)
        {
            operatorIndex = expressionStr.rend() - citr - 1;
            break;
        }
        
        else if (('*' == currentChar || '/' == currentChar) &&
                 operatorIndex == UNINITIALIZED)
        {
            operatorIndex = expressionStr.rend() - citr - 1;
            
            // Continue iterating since multiplication and divide aren't the
            // lowest precedent operators
            continue;
        }
    }
    
    return operatorIndex;
}
    
/// \return True if given string starts with an opening parenthesis and ends
/// with a closing parenthesis.
const bool hasEnclosingParentheses(const std::string& expressionStr)
{
    // The least precedent operator will always exist outside of any parentheses
    // in the expression. If we find an operator that isn't enclosed by
    // parantheses, then the expression doesn't have any enclosing parentheses.
    int operatorIndex = leastPrecedenceOperatorIndex(expressionStr);
    
    static const int NO_OPERATOR = -1;
    
    bool noOutsideOperator = NO_OPERATOR == operatorIndex;
    
    return expressionStr[0] == '(' &&
        expressionStr[expressionStr.length() - 1] == ')' && noOutsideOperator;
}
    
/// \note Assumes the given expression string isn't enclosed in parentheses.
KixExpressionLib::Operator* leastPrecedenceOperator(const char operatorChar)
{
    switch (operatorChar)
    {
        case '*':
        {
            return new KixExpressionLib::MultiplicationOperator();
            break;
        }
        case '/':
        {
            return new KixExpressionLib::DivisionOperator();
            break;
        }
        case '+':
        {
            return new KixExpressionLib::AdditionOperator();
            break;
        }
        case '-':
        {
            return new KixExpressionLib::SubtractionOperator();
            break;
        }
        default:
        {
            // Execution shouldn't reach here - unsupported operator!
            assert(0);
            break;
        }
    }
    
    // Likewise, we should've handled Identity before reaching this point...
    assert(0);
    
    return new KixExpressionLib::IdentityOperator();
}

/// \brief Takes a mathematical expression string and removes any opening and
/// closing parentheses surrounding it (if it has any).
///
/// Example input:
/// "(2*3)"
///
/// Example output:
/// "2*3"
void popParentheses(std::string* expressionStr)
{
    std::string& expressionRef = *expressionStr;
    
    while (hasEnclosingParentheses(expressionRef))
    {
        // Replace last enclosing parenthesis with a null-terminating character
        // to remove it
        expressionRef[expressionRef.length() - 1] = '\0';
        
        // Remove initial, opening parenthesis by re-assigning expression string
        // based on the character following the open parenthesis.
        expressionRef = &(expressionRef.c_str()[1]);
    }
    
    // At the end of this function, the string should no longer have enclosing
    // parentheses.
    assert(!hasEnclosingParentheses(expressionRef));
}
    
}

KixExpressionLib::Expression::Expression(std::string expressionStr)
{
    // Non-const - pop “parens” until a leastPrecendenceOperator is found
    // Parenthesis just dictate order and don’t represent a real “operator” for
    // us to do anything with, so it’s okay to pop them off.
    popParentheses(&expressionStr);

    const int operatorCharIndex = leastPrecedenceOperatorIndex(expressionStr);
    
    static const int NO_OPERATOR = -1;
    
    // If no operator could be found, assume Identity
    if (NO_OPERATOR == operatorCharIndex)
    {
        mOperator = new KixExpressionLib::IdentityOperator();
    }
    else
    {
        mOperator = leastPrecedenceOperator(expressionStr[operatorCharIndex]);
    }

    if (0 < operatorCharIndex)
    {
        // Requires assignment operator
        mOperands[0].pExpression = new Expression(expressionStr.substr(0, operatorCharIndex));
        mOperands[1].pExpression = new Expression(expressionStr.substr(operatorCharIndex + 1,
            expressionStr.length() - 1 - operatorCharIndex));
    }
    else if (-1 == operatorCharIndex)
    {
        mOperands[0].value = atof(expressionStr.c_str());
        mOperands[1].value = mOperands[0].value;
    }
    else
    {
        printf("Invalid expression!\n");
        mOperands[0].pExpression = NULL;
        mOperands[1].pExpression = NULL;
    }
}

KixExpressionLib::Expression::~Expression()
{
    // This is ugly. In order for us to clean up our memory properly, we need
    // to know whether our operands are Expression objects that were dynamically
    // allocated at some point. The only way to know this is to find out if
    // this expression is identity, in which case the operands are simply
    // self-expressing values.
    IdentityOperator* pIdentity = dynamic_cast< IdentityOperator* >(mOperator);
    const bool operandsAreExpressionObjects = !pIdentity;
    
    if (operandsAreExpressionObjects)
    {
        delete mOperands[0].pExpression;
        delete mOperands[1].pExpression;
    }
    
    delete mOperator;
}

const float KixExpressionLib::Expression::Evaluate() const
{
    return mOperator->apply(this);
}

const float KixExpressionLib::Expression::EvaluateOperand(OperandSelection selection) const
{
    // If our operands are NULL, something bad happened during parsing. Return
    // 0.
    if (!mOperands[selection].pExpression)
    {
        return NAN;
    }
    
    return mOperands[selection].pExpression->Evaluate();
}