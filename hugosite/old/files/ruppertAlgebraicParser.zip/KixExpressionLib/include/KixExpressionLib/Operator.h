/*! \file Operator.h

    \brief Defines Operator abstract base class and children implementations.

    \author Chase Ruppert (chase.ruppert@live.com)
*/

#ifndef KIXEXPRESSIONLIB_OPERATOR_H
#define KIXEXPRESSIONLIB_OPERATOR_H

#include "KixExpressionLib/Expression.h"

namespace KixExpressionLib
{

/// \brief Defines an abstract base class for Operators (which apply
/// mathematical operands).
class Operator
{
public:
    
    virtual ~Operator() {};
    
    virtual const float apply(const Expression* pExpression) const = 0;
};
    
class IdentityOperator : public Operator
{
public:
    
    virtual const float apply(const Expression* pExpression) const
    {
        return pExpression->Value();
    }
};
    
class AdditionOperator : public Operator
{
public:
    
    virtual const float apply(const Expression* pExpression) const;
};
    
class SubtractionOperator : public Operator
{
public:
    
    virtual const float apply(const Expression* pExpression) const;
};
    
class MultiplicationOperator : public Operator
{
public:
    
    virtual const float apply(const Expression* pExpression) const;
};
    
class DivisionOperator : public Operator
{
public:
    
    virtual const float apply(const Expression* pExpression) const;
};

}

#endif