/*! \file kixExpression.h

    \brief Interface/entry-point to KIXEYE Expression Library.

    \author Chase Ruppert (chase.ruppert@live.com)
*/

#ifndef KIXEXPRESSIONLIB_KIX_EXPRESSION_H
#define KIXEXPRESSIONLIB_KIX_EXPRESSION_H

namespace KixExpressionLib
{
    const float Evaluate(const char* pExpression);

#if defined( UNIT_TEST )

    void UnitTest();

#endif // #if defined( UNIT_TEST )

}

#endif