/*! \file Expression.h

    \brief Defines Expression class interface

    \author Chase Ruppert (chase.ruppert@live.com)
*/

#ifndef KIXEXPRESSIONLIB_EXPRESSION_H
#define KIXEXPRESSIONLIB_EXPRESSION_H

#include <string>

namespace KixExpressionLib
{
    
class Operator;

/// \brief An expression is simply two operands and an operator.
class Expression
{
public:
    
    Expression(std::string pExpressionStr);
    ~Expression();
    
    const float Evaluate() const;
    
    enum OperandSelection
    {
        FIRST = 0,
        SECOND = 1
    };
    
    const float EvaluateOperand(OperandSelection selection) const;
    
    const float Value() const { return mOperands[0].value; }
    
private:
    
    // Disallow copying for now
    Expression(const Expression& other);
    Expression& operator=(const Expression& other);
    
    union Operand
    {
        float       value;
        Expression* pExpression;
    };
    
    Operand     mOperands[2];
    Operator*   mOperator;
};

}

#endif